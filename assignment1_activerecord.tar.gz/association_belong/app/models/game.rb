class Game < ApplicationRecord
  belongs_to :manufacturer
end
