class Customer < ApplicationRecord
end
#primary key
