class Manufacturer < ApplicationRecord
end
